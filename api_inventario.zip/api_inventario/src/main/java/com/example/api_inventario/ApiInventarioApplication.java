package com.example.api_inventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiInventarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiInventarioApplication.class, args);
	}

}
